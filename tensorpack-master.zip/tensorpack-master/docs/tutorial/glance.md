
## A High-Level Glance

TBD.

You're recommended to glance at the [examples](../examples) to get a feeling about the
structure.
